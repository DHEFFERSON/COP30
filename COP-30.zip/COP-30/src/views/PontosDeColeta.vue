<template>
    <div class="pontos-de-coleta">
      <h1>Pontos de Coleta</h1>
    </div>
  </template>
  
  <style scoped>
  .pontos-de-coleta {
    text-align: center;
    margin-top: 50px;
  }
  </style>
  