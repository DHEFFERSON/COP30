<template>
    <div class="empresa">
      <h1>Área da Empresa</h1>
    </div>
  </template>
  
  <style scoped>
  .empresa {
    text-align: center;
    margin-top: 50px;
  }
  </style>
  