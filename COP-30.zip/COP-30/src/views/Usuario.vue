<template>
    <div class="usuario">
      <h1>Área do Usuário</h1>
    </div>
  </template>
  
  <style scoped>
  .usuario {
    text-align: center;
    margin-top: 50px;
  }
  </style>
  