<template>
  <div class="home">
    <h1>Bem-vindo ao Sistema de Coleta de Resíduos</h1>
  </div>
</template>

<style scoped>
.home {
  text-align: center;
  margin-top: 50px;
}
</style>
