<template>
  <div class="descartar">
    <h1>Descartar</h1>
    
    <div class="input-section">
      <h3>O que deseja descartar?</h3>
      <input type="text" placeholder="Digite o item a ser descartado..." />
    </div>
    
    <div class="input-section">
      <h3>Onde deseja descartar?</h3>
      <input type="text" placeholder="Digite o local de descarte..." />
    </div>

    <div class="submit-section">
      <button>Enviar</button>
    </div>
  </div>
</template>

<style scoped>
.descartar {
  padding: 20px;
  text-align: center;
}

.input-section {
  margin-bottom: 20px;
}

input {
  width: 80%;
  padding: 10px;
  margin-top: 10px;
}

button {
  padding: 10px 20px;
  background-color: #4CAF50;
  color: white;
  border: none;
  cursor: pointer;
}
</style>
