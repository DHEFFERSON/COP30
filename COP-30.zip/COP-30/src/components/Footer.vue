<template>
    <footer>
      <p>&copy; 2024 - Coleta de Resíduos</p>
    </footer>
  </template>
  
  <style scoped>
  footer {
    background-color: #333;
    color: white;
    text-align: center;
    padding: 10px;
    position: relative;
    bottom: 0;
    width: 100%;
  }
  </style>
  