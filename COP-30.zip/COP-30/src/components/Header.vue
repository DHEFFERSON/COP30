<template>
  <header>
    <nav>
      <ul>
        <li><router-link to="/">Home</router-link></li>
        <li><router-link to="/pontos-de-coleta">Pontos de Coleta</router-link></li>
        <li><router-link to="/empresa">Empresa</router-link></li>
        <li><router-link to="/usuario">Usuário</router-link></li>
        <li><router-link to="/descartar">Descartar</router-link></li>
      </ul>
    </nav>
  </header>
</template>

<style scoped>
header {
  background-color: #4CAF50;
  padding: 15px;
  color: white;
}

nav ul {
  list-style: none;
  display: flex;
  justify-content: space-around;
}

nav ul li {
  display: inline;
}

router-link {
  color: white;
  text-decoration: none;
}
</style>