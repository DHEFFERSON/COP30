import { createRouter, createWebHistory } from 'vue-router'
import Home from '../views/Home.vue'
import Descartar from '../views/Descartar.vue'

const routes = [
  { path: '/', name: 'Home', component: Home },
  { path: '/descartar', name: 'Descartar', component: Descartar },
]

const router = createRouter({
  history: createWebHistory('/app/'),
  routes,
})

export default router
