import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  // Definir a base URL, útil se seu app estiver em um subdiretório
  base: '/app/',  // Altere conforme o seu caminho de implantação (deixe vazio se não usar subdiretórios)

  // Plugins
  plugins: [vue()],

  // Configurações do servidor de desenvolvimento
  server: {
    // Porta do servidor local
    port: 3000,  // Mude para qualquer porta que você prefira (5173 é o padrão)

    // Configurações de HMR (Hot Module Replacement)
    hmr: {
      protocol: 'ws',  // Protocolo de WebSocket (padrão para HMR)
      host: 'localhost',  // Host para HMR (alterar se rodar em ambiente diferente)
    },

    // Se precisar usar proxies (para backend, API, etc.), pode adicionar a opção abaixo:
    /*
    proxy: {
      '/api': {
        target: 'http://localhost:8000',  // URL do backend Django, por exemplo
        changeOrigin: true,
        rewrite: (path) => path.replace(/^\/api/, '')
      }
    }
    */
  },
})
